#import "HTTPServer.h"
#import "ScriptRunner.h"
#import "FileStore.h"
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>

@interface HTTPServer ()
@property(nonatomic) uint16_t port;
@property(nonatomic, copy) NSString *pairingToken;
@end

@implementation HTTPServer

- (instancetype)initWithPort:(uint16_t)port {
    if ((self = [super init])) {
        _port = port;
        _pairingToken = [self loadOrCreatePairingToken];
    }
    return self;
}

static NSString *jsonString(id obj) {
    NSData *d = [NSJSONSerialization dataWithJSONObject:obj options:0 error:nil];
    return [[NSString alloc] initWithData:d encoding:NSUTF8StringEncoding] ?: @"{}";
}

static NSString *urlDecode(NSString *s) {
    return [s stringByRemovingPercentEncoding] ?: s;
}

static NSDictionary *parseQuery(NSString *q) {
    NSMutableDictionary *m = [NSMutableDictionary dictionary];
    for (NSString *pair in [q componentsSeparatedByString:@"&"]) {
        NSRange eq = [pair rangeOfString:@"="];
        if (eq.location == NSNotFound) {
            if (pair.length) m[urlDecode(pair)] = @"";
        } else {
            NSString *k = [pair substringToIndex:eq.location];
            NSString *v = [pair substringFromIndex:eq.location + 1];
            m[urlDecode(k)] = urlDecode(v);
        }
    }
    return m;
}

static NSDictionary *parseHeaders(NSArray<NSString *> *lines) {
    NSMutableDictionary *headers = [NSMutableDictionary dictionary];
    for (NSUInteger i = 1; i < lines.count; i++) {
        NSString *line = lines[i];
        if (line.length == 0) break;
        NSRange colon = [line rangeOfString:@":"];
        if (colon.location == NSNotFound) continue;
        NSString *k = [[[line substringToIndex:colon.location] stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceCharacterSet] lowercaseString];
        NSString *v = [[line substringFromIndex:colon.location + 1] stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceCharacterSet];
        headers[k] = v;
    }
    return headers;
}

- (NSString *)tokenPath {
    return [[FileStore baseDirectory] stringByAppendingPathComponent:@"token.txt"];
}

- (NSString *)loadOrCreatePairingToken {
    [FileStore ensureDirectories];
    NSString *path = [self tokenPath];
    NSString *existing = [[NSString stringWithContentsOfFile:path encoding:NSUTF8StringEncoding error:nil]
                          stringByTrimmingCharactersInSet:NSCharacterSet.whitespaceAndNewlineCharacterSet];
    if (existing.length >= 16) return existing;

    NSString *token = [[[NSUUID UUID].UUIDString stringByReplacingOccurrencesOfString:@"-" withString:@""] lowercaseString];
    [token writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:nil];
    chmod(path.fileSystemRepresentation, 0644); // protects from LAN users; readable locally for pairing convenience
    return token;
}

- (BOOL)isAuthorizedWithHeaders:(NSDictionary *)headers query:(NSDictionary *)query {
    NSString *provided = headers[@"x-mycontrol-token"] ?: query[@"token"] ?: @"";
    return provided.length > 0 && [provided isEqualToString:self.pairingToken];
}

- (NSData *)indexHTML {
    NSString *path = [[FileStore webDirectory] stringByAppendingPathComponent:@"index.html"];
    NSData *d = [NSData dataWithContentsOfFile:path];
    if (d) return d;
    NSString *fallback = @"<html><body><h1>MyControl</h1><p>Web UI missing.</p></body></html>";
    return [fallback dataUsingEncoding:NSUTF8StringEncoding];
}

- (void)sendResponse:(int)fd status:(NSString *)status contentType:(NSString *)contentType body:(NSData *)body {
    NSString *header = [NSString stringWithFormat:@"HTTP/1.1 %@\r\nContent-Type: %@\r\nContent-Length: %lu\r\nConnection: close\r\nCache-Control: no-store\r\nAccess-Control-Allow-Origin: *\r\nAccess-Control-Allow-Headers: Content-Type, X-MyControl-Token\r\nAccess-Control-Allow-Methods: GET, POST, OPTIONS\r\n\r\n", status, contentType, (unsigned long)body.length];
    NSData *h = [header dataUsingEncoding:NSUTF8StringEncoding];
    send(fd, h.bytes, h.length, 0);
    if (body.length) send(fd, body.bytes, body.length, 0);
}

- (void)sendJSON:(int)fd status:(NSString *)status object:(NSDictionary *)object {
    NSData *d = [jsonString(object) dataUsingEncoding:NSUTF8StringEncoding];
    [self sendResponse:fd status:status contentType:@"application/json" body:d];
}

- (void)handleClient:(int)fd {
    NSMutableData *request = [NSMutableData data];
    uint8_t buf[4096];
    ssize_t n;
    NSRange headerEnd = NSMakeRange(NSNotFound, 0);
    NSInteger contentLength = 0;

    while ((n = recv(fd, buf, sizeof(buf), 0)) > 0) {
        [request appendBytes:buf length:(NSUInteger)n];
        NSString *tmp = [[NSString alloc] initWithData:request encoding:NSUTF8StringEncoding];
        if (!tmp) continue;
        headerEnd = [tmp rangeOfString:@"\r\n\r\n"];
        if (headerEnd.location != NSNotFound) {
            NSRegularExpression *re = [NSRegularExpression regularExpressionWithPattern:@"Content-Length:\\s*(\\d+)" options:NSRegularExpressionCaseInsensitive error:nil];
            NSTextCheckingResult *m = [re firstMatchInString:tmp options:0 range:NSMakeRange(0, headerEnd.location)];
            if (m.numberOfRanges > 1) contentLength = [[tmp substringWithRange:[m rangeAtIndex:1]] integerValue];
            NSUInteger bodyStart = headerEnd.location + headerEnd.length;
            if (request.length >= bodyStart + (NSUInteger)contentLength) break;
        }
    }

    NSString *raw = [[NSString alloc] initWithData:request encoding:NSUTF8StringEncoding] ?: @"";
    NSArray<NSString *> *lines = [raw componentsSeparatedByString:@"\r\n"];
    NSString *first = lines.firstObject ?: @"";
    NSArray *parts = [first componentsSeparatedByString:@" "];
    NSString *method = parts.count > 0 ? parts[0] : @"GET";
    NSString *target = parts.count > 1 ? parts[1] : @"/";
    NSString *path = target;
    NSString *queryString = @"";
    NSRange qr = [target rangeOfString:@"?"];
    if (qr.location != NSNotFound) {
        path = [target substringToIndex:qr.location];
        queryString = [target substringFromIndex:qr.location + 1];
    }
    NSDictionary *query = parseQuery(queryString);
    NSDictionary *headers = parseHeaders(lines);

    NSString *bodyString = @"";
    NSRange split = [raw rangeOfString:@"\r\n\r\n"];
    if (split.location != NSNotFound) bodyString = [raw substringFromIndex:split.location + split.length];

    if ([method isEqualToString:@"OPTIONS"]) {
        [self sendResponse:fd status:@"204 No Content" contentType:@"text/plain" body:[NSData data]];
        return;
    }

    if ([path isEqualToString:@"/"]) {
        [self sendResponse:fd status:@"200 OK" contentType:@"text/html; charset=utf-8" body:[self indexHTML]];
        return;
    }

    if ([path isEqualToString:@"/api/status"]) {
        [self sendJSON:fd status:@"200 OK" object:@{
            @"ok": @YES,
            @"name": @"MyControl LAN",
            @"version": @"0.2.0",
            @"port": @(self.port),
            @"pairingRequired": @YES
        }];
        return;
    }

    if (![self isAuthorizedWithHeaders:headers query:query]) {
        [self sendJSON:fd status:@"401 Unauthorized" object:@{ @"ok": @NO, @"error": @"Invalid pairing token" }];
        return;
    }

    if ([path isEqualToString:@"/api/scripts"] && [method isEqualToString:@"GET"]) {
        [self sendJSON:fd status:@"200 OK" object:@{ @"ok": @YES, @"scripts": [FileStore listScripts] }];
        return;
    }

    if ([path isEqualToString:@"/api/save"] && [method isEqualToString:@"POST"]) {
        NSString *name = query[@"name"] ?: @"script.lua";
        NSError *e = nil;
        BOOL ok = [FileStore saveScriptNamed:name content:bodyString error:&e];
        [self sendJSON:fd status:(ok ? @"200 OK" : @"500 Internal Server Error") object:@{ @"ok": @(ok), @"error": e.localizedDescription ?: @"" }];
        return;
    }

    if ([path isEqualToString:@"/api/load"] && [method isEqualToString:@"GET"]) {
        NSString *name = query[@"name"] ?: @"script.lua";
        NSError *e = nil;
        NSString *content = [FileStore loadScriptNamed:name error:&e] ?: @"";
        [self sendJSON:fd status:(e ? @"404 Not Found" : @"200 OK") object:@{ @"ok": @(e == nil), @"content": content, @"error": e.localizedDescription ?: @"" }];
        return;
    }

    if ([path isEqualToString:@"/api/run"] && [method isEqualToString:@"POST"]) {
        NSDictionary *result = [ScriptRunner runLuaSource:bodyString];
        [self sendJSON:fd status:@"200 OK" object:result];
        return;
    }

    NSData *d = [@"Not found" dataUsingEncoding:NSUTF8StringEncoding];
    [self sendResponse:fd status:@"404 Not Found" contentType:@"text/plain; charset=utf-8" body:d];
}

- (void)start {
    [FileStore ensureDirectories];
    int server = socket(AF_INET, SOCK_STREAM, 0);
    if (server < 0) {
        NSLog(@"[MyControl] socket() failed");
        return;
    }
    int yes = 1;
    setsockopt(server, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(yes));
    struct sockaddr_in addr = {0};
    addr.sin_family = AF_INET;
    addr.sin_port = htons(self.port);
    addr.sin_addr.s_addr = INADDR_ANY; // LAN control: http://IPHONE_IP:9999
    if (bind(server, (struct sockaddr *)&addr, sizeof(addr)) != 0 || listen(server, 8) != 0) {
        NSLog(@"[MyControl] Failed to bind port %d", self.port);
        close(server);
        return;
    }
    NSLog(@"[MyControl] Listening on 0.0.0.0:%d", self.port);
    NSLog(@"[MyControl] Pairing token stored at %@", [self tokenPath]);

    while (1) {
        int client = accept(server, NULL, NULL);
        if (client < 0) continue;
        dispatch_async(dispatch_get_global_queue(QOS_CLASS_UTILITY, 0), ^{
            @autoreleasepool { [self handleClient:client]; close(client); }
        });
    }
}

@end
