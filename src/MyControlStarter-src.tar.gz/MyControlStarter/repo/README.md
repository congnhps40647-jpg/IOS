# Free APT repo via GitHub Pages

1. Build the package: `./scripts/publish_deb.sh`
2. Commit the new `.deb` in `repo/debs/` and push to `main`.
3. In GitHub repository Settings -> Pages, set Source to **GitHub Actions**.
4. After the workflow finishes, the repo URL is normally:
   `https://YOUR_GITHUB_USERNAME.github.io/YOUR_REPOSITORY_NAME/`
5. Add that URL in Sileo/Zebra Sources.

The GitHub Action generates `Packages`, `Packages.gz`, and `Release` automatically.
