# MyControl LAN v0.2

Starter project for a jailbreak-side daemon + LAN Web IDE. It is intended for automation/research on apps and devices you own or are authorized to test.

## What v0.2 includes

- Rootless Theos package for iOS 15+
- LaunchDaemon `mycontrold`
- HTTP server listening on `0.0.0.0:9999`
- Web IDE accessible from another device on the same LAN
- Pairing token required for save/load/run APIs
- Lua runner, file save/load/list, console output
- `mycontrolctl` helper
- Free static APT repository template for GitHub Pages

## Build on Windows / WSL2

Install Theos in WSL, then:

```bash
cd MyControlStarter
make clean package FINALPACKAGE=1
```

The `.deb` will be in `packages/`.

Theos rootless mode sets the package architecture to `iphoneos-arm64`; the project targets `arm64`, which is sufficient for this CLI daemon. The package is intended for rootless iOS 15+.

## Install locally first

Copy the generated `.deb` to the iPhone and install it with your package manager or `dpkg -i`.

After installation:

```sh
mycontrolctl status
mycontrolctl ip
mycontrolctl token
mycontrolctl url
```

`mycontrolctl url` prints a convenience URL like:

```text
http://192.168.1.50:9999/#PAIRING_TOKEN
```

Open that URL on a PC connected to the same Wi-Fi. The token is placed in the URL fragment (`#...`), so it is not sent as part of the initial HTTP request; the Web UI stores it locally and sends it in the `X-MyControl-Token` header for privileged API calls.

You can also open:

```text
http://IPHONE_IP:9999
```

then paste the output of `mycontrolctl token` into the Pairing Token field.

## Free Sileo/Zebra repo with GitHub Pages

This project contains:

```text
repo/debs/
.github/workflows/publish-repo.yml
scripts/publish_deb.sh
```

Run:

```bash
./scripts/publish_deb.sh
```

Then push the project to a **public GitHub repository**. In GitHub `Settings -> Pages`, choose **GitHub Actions** as the source. The included workflow builds `Packages`, `Packages.gz`, and `Release`, then publishes the APT repo.

Your source URL will normally be:

```text
https://YOUR_GITHUB_USERNAME.github.io/YOUR_REPOSITORY_NAME/
```

Add that URL under Sources in Sileo or Zebra. GitHub Pages is free for public repositories under GitHub's current plan/policy limits.

## Network security

The daemon intentionally binds to all device interfaces (`0.0.0.0`) so LAN control works. State-changing APIs require the pairing token. Do not port-forward TCP 9999 to the public internet. Keep control on a trusted LAN or VPN.

## Commands

```sh
mycontrolctl status
mycontrolctl ip
mycontrolctl token
mycontrolctl url
mycontrolctl restart
mycontrolctl logs
```

## Current scope

This starter does not implement device-identity spoofing, license bypassing, or account-creation automation. Touch/OCR/screenshot modules can be added separately for authorized app/device testing.
