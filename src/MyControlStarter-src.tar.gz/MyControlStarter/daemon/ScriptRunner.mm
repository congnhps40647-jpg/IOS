#import "ScriptRunner.h"
#import "FileStore.h"
#include <spawn.h>
#include <sys/wait.h>
#include <unistd.h>

extern char **environ;

@implementation ScriptRunner

+ (NSString *)luaPath {
    NSArray<NSString *> *candidates = @[@"/var/jb/usr/bin/lua", @"/usr/bin/lua", @"/var/jb/usr/bin/lua5.4", @"/usr/bin/lua5.4"];
    for (NSString *p in candidates) if ([[NSFileManager defaultManager] isExecutableFileAtPath:p]) return p;
    return @"";
}

+ (NSDictionary *)runLuaSource:(NSString *)source {
    [FileStore ensureDirectories];
    NSString *lua = [self luaPath];
    if (!lua.length) {
        return @{ @"ok": @NO,
                  @"exitCode": @127,
                  @"output": @"Lua executable not found. Install a Lua package on the jailbroken device (for example lua 5.4), then restart mycontrold." };
    }

    NSString *tmpDir = [[FileStore baseDirectory] stringByAppendingPathComponent:@"tmp"];
    [[NSFileManager defaultManager] createDirectoryAtPath:tmpDir withIntermediateDirectories:YES attributes:nil error:nil];
    NSString *path = [tmpDir stringByAppendingPathComponent:[NSString stringWithFormat:@"run-%@.lua", NSUUID.UUID.UUIDString]];
    NSError *writeError = nil;
    if (![source writeToFile:path atomically:YES encoding:NSUTF8StringEncoding error:&writeError]) {
        return @{ @"ok": @NO, @"exitCode": @1, @"output": writeError.localizedDescription ?: @"Could not write script" };
    }

    int pipefd[2];
    if (pipe(pipefd) != 0) {
        [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
        return @{ @"ok": @NO, @"exitCode": @1, @"output": @"pipe() failed" };
    }

    posix_spawn_file_actions_t actions;
    posix_spawn_file_actions_init(&actions);
    posix_spawn_file_actions_adddup2(&actions, pipefd[1], STDOUT_FILENO);
    posix_spawn_file_actions_adddup2(&actions, pipefd[1], STDERR_FILENO);
    posix_spawn_file_actions_addclose(&actions, pipefd[0]);

    pid_t pid = 0;
    const char *argv[] = { lua.fileSystemRepresentation, path.fileSystemRepresentation, NULL };
    int spawnResult = posix_spawn(&pid, lua.fileSystemRepresentation, &actions, NULL, (char * const *)argv, environ);
    posix_spawn_file_actions_destroy(&actions);
    close(pipefd[1]);

    if (spawnResult != 0) {
        close(pipefd[0]);
        [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
        return @{ @"ok": @NO, @"exitCode": @(spawnResult), @"output": [NSString stringWithFormat:@"posix_spawn failed: %d", spawnResult] };
    }

    NSMutableData *out = [NSMutableData data];
    uint8_t buf[4096];
    ssize_t n;
    while ((n = read(pipefd[0], buf, sizeof(buf))) > 0) [out appendBytes:buf length:(NSUInteger)n];
    close(pipefd[0]);

    int status = 0;
    waitpid(pid, &status, 0);
    int code = WIFEXITED(status) ? WEXITSTATUS(status) : 1;
    [[NSFileManager defaultManager] removeItemAtPath:path error:nil];

    NSString *output = [[NSString alloc] initWithData:out encoding:NSUTF8StringEncoding] ?: @"";
    return @{ @"ok": @(code == 0), @"exitCode": @(code), @"output": output };
}

@end
