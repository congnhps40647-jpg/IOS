print("MyControl Lua OK")
for i = 1, 3 do
  print("tick", i)
end
