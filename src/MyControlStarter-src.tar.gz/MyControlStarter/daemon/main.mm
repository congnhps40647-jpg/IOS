#import <Foundation/Foundation.h>
#import "HTTPServer.h"
#import "FileStore.h"

int main(int argc, char **argv) {
    @autoreleasepool {
        [FileStore ensureDirectories];
        NSLog(@"[MyControl] starting...");
        HTTPServer *server = [[HTTPServer alloc] initWithPort:9999];
        [server start];
    }
    return 0;
}
