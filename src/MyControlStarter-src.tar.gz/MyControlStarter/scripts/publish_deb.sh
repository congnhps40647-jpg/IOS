#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
make clean package FINALPACKAGE=1
DEB="$(ls -t packages/*.deb | head -n1)"
cp "$DEB" repo/debs/
echo "Copied: $DEB -> repo/debs/"
echo "Now git add/commit/push. GitHub Actions will regenerate Packages/Release and publish Pages."
